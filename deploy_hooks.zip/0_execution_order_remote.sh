echo "this will be executed first in the 'deploy' hook folder"
