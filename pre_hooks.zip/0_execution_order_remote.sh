echo "this will be executed first in the 'pre' hook folder"
