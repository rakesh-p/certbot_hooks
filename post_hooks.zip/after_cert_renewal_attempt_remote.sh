echo "this scripts in the 'post' folder will run after every attempt to renew the certificate"
current_dir=$(pwd)
echo "script folder  ${current_dir}"
