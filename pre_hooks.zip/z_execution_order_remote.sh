echo "this will be executed last in the 'pre' hook folder"
