echo "the scripts in the 'deploy' folder will run only after successful certificate renewal"
current_dir=$(pwd)
echo "script folder  ${current_dir}"
