echo "this scripts in the 'pre' folder will run before every attempt to renew the certificate"
current_dir=`pwd`
echo "script folder  ${current_dir}"